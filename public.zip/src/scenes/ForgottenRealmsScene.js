import Phaser from 'phaser'
 export default class ForgottenRealmsScene extends
 Phaser.Scene
 {
constructor(){
super('forgotten-realms-scene')
 }
 init(){
   //template
    this.platforms= undefined
    this.player = undefined 
    this.stars= undefined
    this.cursor = undefined
    this.scoreText = undefined
this.score = 0
this.bombs = undefined
//~template
this.hp = 100 //healthpoint
this.heal = undefined 
this.healsfx = undefined
this.key = undefined
this.bombs2 = undefined
 }
 preload(){
   this.load.image('sky','images/sky.png')//background
   this.load.image('cloud','images/cloud.png')
   this.load.image('moon','images/moon.png')
   this.load.image('cloud2','images/cloud.png')
    this.load.image('ground','images/platform.png')
    this.load.spritesheet('portal','images/portal.png',
    {frameWidth:32, frameHeight:32})//~background
    //template
this.load.image('star', 'images/star.png')
this.load.image('bomb', 'images/bomb.png')
   this.load.spritesheet('dude','images/dude.png',
   {frameWidth:32, frameHeight:48}
   )
   //~template
   //items
this.load.image('heal','images/heal.png')
this.load.audio('healsfx', 'sfx/healsfx.mp3')
this.load.spritesheet('keys', 'images/key.png',
{frameWidth:32, frameHeight:32})
//~items
}
   create(){
      //background
    const gameWidht = this.scale.width*0.5;
    const gameHeight = this.scale.height*0.5;
    this.add.image(gameWidht,gameHeight,'sky')
    this.add.image(gameWidht,gameHeight,'cloud')
    this.add.image(gameWidht,gameHeight,'moon')
    this.portal=this.add.sprite(1860,80,'portal').setScale(1.5)
    this.anims.create({
      key:'openportal', 
      frames :this.anims.generateFrameNumbers('portal',{start:1, end:7}),
      frameRate:10,
      repeat:1
     });
     //~background
     //template
    this.platforms=this.physics.add.staticGroup()
    this.player=this.physics.add.sprite(gameWidht,gameHeight,'dude')
    this.player.setCollideWorldBounds(true) 
    this.physics.add.collider(this.player,this.platforms)
    this.platforms.create(400, 1030, 'ground').setScale(2)
    .refreshBody();
    this.platforms.create(1600, 1030, 'ground').setScale(2)
    .refreshBody();
    this.platforms.create(gameWidht,gameHeight+47, 'ground')
    .refreshBody();
    this.platforms.create(1550, 0, 'ground').setScale(2)
    .refreshBody();
    this.platforms.create(2000, 128, 'ground')
    .refreshBody();
    this.stars = this.physics.add.group({
        key: 'star',
        repeat:12,
        setXY: {x:50, y:100, stepX:150} 
        });
        this.physics.add.collider(this.stars, this.platforms)
        // @ts-ignore
        this.stars.children.iterate(function (child){
            // @ts-ignore
             child.setBounceY(0.5);
             });
             this.cursor=this.input.keyboard.createCursorKeys()
             this.anims.create({
               key:'left', 
               frames :this.anims.generateFrameNumbers('dude',{start:0, end:3}),
               frameRate:10,
               repeat:-1
              
              });

              this.anims.create({
               key: 'turn',
               frames: [ { key: 'dude', frame: 4 } ], 
               frameRate: 20
               });
               //animation to the right
               this.anims.create({
               key: 'right',
               frames: this.anims.generateFrameNumbers('dude', 
                { start: 5, end: 8 }),
               frameRate: 10,
               repeat: -1
               });
              this.physics.add.overlap(
               this.player,
               this.stars,
               this.collectStar,
               null,
               this
               )
               this.scoreText= this.add.text(300,16,'Score : 0',{
                  fontSize: '32px', color: 'yellow' 
                   });
                   this.bombs = this.physics.add.group({
                     key: 'bomb',
                     repeat:5,
                     setXY: {x:30, y:0, stepX:120} 
                     });
                     this.physics.add.collider(this.bombs, this.platforms)

                     // @ts-ignore
                     this.bombs.children.iterate(function (child){
                         // @ts-ignore
                          child.setBounceY(0.5);
                          });
                          this.physics.add.overlap(
                           this.player,
                           this.bombs,
                           this.gameOver,
                           null,
                           this
                           )
                           this.scoreText= this.add.text(300,16,'Score : 0',{
                              fontSize: '32px', color: 'yellow' 
                               });
                               //~template

                               //increaseLife
                                  //items
                                  this.heal = this.physics.add.group({
                                    key: 'heal',
                                    repeat:1,
                                    setXY: {x:100, y:500} 
                                    });
                                    this.physics.add.collider(this.heal, this.platforms)
                                    this.key=this.add.sprite(800,500,'keys')
                                    this.anims.create({
                                      key:'rotatekey', 
                                      frames :this.anims.generateFrameNumbers('keys',{start:0, end:23}),
                                      frameRate:10,
                                      repeat:-1
                                     });
                                  //~items
                               this.physics.add.overlap(
                                 this.player,
                                 this.heal,
                                 this.increaseLife,
                                 null,
                                 this
                                 )
                                 this.physics.add.overlap(
                                    this.player,
                                    this.key,
                                    this.collectKey,
                                    null,
                                    this
                                    )
                                 //~increaseLife
                                 //bombs
                              /*
                                 bombs2 = this.physics.add.group()
                                 this.physics.add.collider(bombs2, platforms)
                                 this.physics.add.collider(
                                    this.player,
                                    this.bombs,
                                    this.hitBomb,
                                    null,
                                    this
                                 );
                                 *///~bombs
                                
}
update(){
   this.key.anims.play('rotatekey', true)
   //background
   if (this.cursor.down.isDown){
   this.portal.anims.play('openportal',true)}
   //~background
   //template
   if (this.cursor.left.isDown){
      this.player.setVelocity(-200,200)
      this.player.anims.play('left',true)
       }
      else if(this.cursor.right.isDown){
      this.player.setVelocity(200,200)
      this.player.anims.play('right',true)
       }
      else{
      this.player.setVelocity(0,0)
      this.player.anims.play('turn')
       }
       if (this.cursor.up.isDown){
         this.player.setVelocity(0, -200)
         this.player.anims.play('turn')
      
          }
          if(this.score >= 100){
            this.physics.pause()
            this.add.text(300,300,'You Win!!!', { 
            fontSize: '48px', 
             color:'yellow'
            })}
         //~template
}
//template
collectStar(player, star){
   star.destroy()
  this.score += 10;
  this.scoreText.setText('Score : '+this.score );
   }
   gameOver(player, bombs){
      this.physics.pause()
      this.add.text(300,300,'Game Over!!!', { 
       fontSize: '48px', color:'yellow' })
       }
        //~template

//items
collectKey(player, keys){
   keys.destroy()
}

increaseLife(player, heal){
   heal.destroy()
}
//~items
//portal
portalWin(player,portal){
   player.destroy()
   this.add.text(960,540,'win?',{
      fontSize: '48px', color:'black'
   })
}
//~portal
 } 

